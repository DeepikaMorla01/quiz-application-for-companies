from flask import Flask, render_template, request, redirect, session
import sqlite3
import random

app = Flask(__name__)
app.secret_key = "quiz_secret"


# -------------------------
# DATABASE INITIALIZATION
# -------------------------
def init_db():

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS results(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        topic TEXT,
        score INTEGER,
        total INTEGER
    )
    """)

    conn.commit()
    conn.close()


init_db()


# -------------------------
# QUESTION GENERATOR
# -------------------------
def generate_questions(topic, count):

    facts = {

        "python":[
            {"term":"Python","definition":"Programming Language"},
            {"term":"Pandas","definition":"Data Analysis Library"},
            {"term":"Tuple","definition":"Immutable Data Type"},
            {"term":"List","definition":"Mutable Data Structure"},
            {"term":"#","definition":"Comment Symbol"}
        ],

        "ai":[
            {"term":"AI","definition":"Artificial Intelligence"},
            {"term":"Machine Learning","definition":"Learning from data"},
            {"term":"Neural Network","definition":"Brain inspired model"},
            {"term":"Dataset","definition":"Collection of training data"},
            {"term":"Automation","definition":"Performing tasks automatically"}
        ],

        "html":[
            {"term":"HTML","definition":"Hyper Text Markup Language"},
            {"term":"<a>","definition":"Hyperlink Tag"},
            {"term":"<img>","definition":"Image Tag"},
            {"term":"<p>","definition":"Paragraph Tag"},
            {"term":"<table>","definition":"Table Tag"}
        ]
    }

    templates = [
        "What is {term}?",
        "Which option best describes {term}?",
        "{term} refers to what concept?",
        "Identify the correct definition of {term}.",
        "Which statement explains {term}?"
    ]

    topic = topic.lower()

    if topic not in facts:
        topic = "python"

    questions = []

    for fact in facts[topic]:

        question_text = random.choice(templates).replace("{term}", fact["term"])

        options = [
            fact["definition"],
            "Hardware Device",
            "Operating System",
            "Networking Protocol"
        ]

        random.shuffle(options)

        questions.append({
            "question": question_text,
            "options": options,
            "answer": fact["definition"]
        })

    return random.sample(questions, min(count, len(questions)))


# -------------------------
# LOGIN PAGE
# -------------------------
@app.route("/")
def login_page():
    return render_template("login.html")


# -------------------------
# REGISTER PAGE
# -------------------------
@app.route("/register_page")
def register_page():
    return render_template("register.html")


# -------------------------
# REGISTER USER
# -------------------------
@app.route("/register", methods=["POST"])
def register():

    username = request.form["username"]
    password = request.form["password"]

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO users(username,password) VALUES(?,?)",
        (username,password)
    )

    conn.commit()
    conn.close()

    return redirect("/")


# -------------------------
# LOGIN USER
# -------------------------
@app.route("/login", methods=["POST"])
def login():

    username = request.form["username"]
    password = request.form["password"]

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (username,password)
    )

    user = cursor.fetchone()
    conn.close()

    if user:
        session["username"] = username
        return redirect("/dashboard")

    return "Invalid Login"


# -------------------------
# DASHBOARD
# -------------------------
@app.route("/dashboard")
def dashboard():

    if "username" not in session:
        return redirect("/")

    username = session["username"]

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute(
        "SELECT topic,score,total FROM results WHERE username=?",
        (username,)
    )

    results = cursor.fetchall()
    conn.close()

    return render_template("dashboard.html", results=results)


# -------------------------
# START QUIZ
# -------------------------
@app.route("/start_quiz", methods=["POST"])
def start_quiz():

    if "username" not in session:
        return redirect("/")

    topic = request.form["topic"]
    count = int(request.form["count"])

    session["topic"] = topic

    questions = generate_questions(topic, count)

    session["questions"] = questions

    return render_template("quiz.html", questions=questions)


# -------------------------
# SUBMIT QUIZ
# -------------------------
@app.route("/submit", methods=["POST"])
def submit():

    if "username" not in session:
        return redirect("/")

    questions = session["questions"]
    topic = session["topic"]
    username = session["username"]

    score = 0

    for i,q in enumerate(questions):

        selected = request.form.get(f"q{i}")

        if selected == q["answer"]:
            score += 1

    total = len(questions)

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO results(username,topic,score,total) VALUES(?,?,?,?)",
        (username,topic,score,total)
    )

    conn.commit()
    conn.close()

    return render_template("result.html", score=score, total=total)


# -------------------------
# LEADERBOARD
# -------------------------
@app.route("/leaderboard")
def leaderboard():

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("""
    SELECT username,topic,score,total
    FROM results
    ORDER BY score DESC
    LIMIT 10
    """)

    leaders = cursor.fetchall()
    conn.close()

    return render_template("leaderboard.html", leaders=leaders)


# -------------------------
# RUN APP
# -------------------------
if __name__ == "__main__":
    app.run(debug=True)